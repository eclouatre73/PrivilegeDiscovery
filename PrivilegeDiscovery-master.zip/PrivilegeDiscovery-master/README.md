# PrivilegeDiscovery
PowerShell scripts for discovering Privileges and Privilege use in Active Directory
